public class BinarySearchTree {
    public static void main(String[] args) {
        Node root = null;
        root = insert(root,B 5376 BY);
        insert(root,G 6547 GE);
        insert(root,H 6384 HK);
        insert(root,AD 6536 ZA);
        insert(root,T 6538 AR);
        insert(root,D 7462 SS);
        insert(root,R 8824 DK);
        inorder(root);
    }
}

}
